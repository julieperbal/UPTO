var $rouge = document.getElementById("rouge"),
$vert = document.getElementById("vert");

$rouge.classList.add("chapitre1");
